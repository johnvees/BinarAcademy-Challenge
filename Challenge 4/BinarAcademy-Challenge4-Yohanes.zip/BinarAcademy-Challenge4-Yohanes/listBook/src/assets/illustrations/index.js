import ILSampleCover from './sampleImage.png';
import ILLogo from './logo.png';

export {ILSampleCover, ILLogo};
