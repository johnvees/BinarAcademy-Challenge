import DetailHeader from './detailHeader';
import DetailOverview from './detailOverview';

export {DetailHeader, DetailOverview};
