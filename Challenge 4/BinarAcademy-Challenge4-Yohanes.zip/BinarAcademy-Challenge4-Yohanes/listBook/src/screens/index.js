import Detail from './Detail';
import Home from './Home';
import Login from './Login';
import Logout from './Logout';
import Register from './Register';
import Successful from './Successful';

export {Detail, Home, Login, Logout, Register, Successful};
