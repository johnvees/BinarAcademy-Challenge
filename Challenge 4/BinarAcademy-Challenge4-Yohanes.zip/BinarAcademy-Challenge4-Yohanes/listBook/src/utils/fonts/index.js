export const fonts = {
  primary: {
    400: 'sfprodisplay_regular',
    500: 'sfprodisplay_medium',
  },
  secondary: {
    600: 'Gilroy-Semibold',
    700: 'Gilroy-Bold',
  },
};
