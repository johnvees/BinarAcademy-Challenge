export const firebaseService =
  'https://fcm.googleapis.com/fcm/send';
