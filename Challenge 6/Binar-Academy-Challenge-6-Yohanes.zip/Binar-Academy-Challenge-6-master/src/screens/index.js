import Register from './Register';
import Login from './Login';
import Home from './Home';
import Geo from './Geolocation';
import QRCode from './QRCode';
import AfterSuccess from './QRCode/AfterSuccess';

export {Register, Login, Home, Geo, QRCode, AfterSuccess};
