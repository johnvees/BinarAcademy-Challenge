import {StyleSheet, Text, View} from 'react-native';
import React from 'react';
import Root from './routes';

const App = () => {
  return <Root />;
};

export default App;

const styles = StyleSheet.create({});
