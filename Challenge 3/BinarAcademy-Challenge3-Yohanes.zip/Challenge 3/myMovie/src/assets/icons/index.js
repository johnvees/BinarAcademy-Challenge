import ICStar from './ic_star.png';

export {ICStar};
