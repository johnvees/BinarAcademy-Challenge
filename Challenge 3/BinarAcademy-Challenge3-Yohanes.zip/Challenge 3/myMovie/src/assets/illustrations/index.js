import ILAvatar from './avatar.png';
import ILWaving from './waving.png';
import ILPoster from './exposter.png';
import ILLogo from './logo.png';
import ILNoConnection from './noConnection.png';

export {ILAvatar, ILWaving, ILPoster, ILLogo, ILNoConnection};
