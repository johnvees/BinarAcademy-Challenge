export const fonts = {
  primary: {
    400: 'sfprodisplay_regular',
    500: 'sfprodisplay_medium',
    700: 'sfprodisplay_bold',
  },
};
