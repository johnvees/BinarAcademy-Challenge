export const BASE_URL = 'http://code.aldipee.com/api/v1/movies';

export const credits = `https://api.themoviedb.org/3/movie/`;

export const ACCESS_TOKEN =
  'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI5YTUyNDNhODdlYWFkZWM3Yzc0NjA5NTFhMjEwNjA5OCIsInN1YiI6IjYyMzA5ODA5NmQxYmIyMDAxZDY3NWM0MCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.gfew_qfaII4a1Kk0unDKAxx8sofcaTL6euGGibnxO0w';

export const ImageUrl = 'https://image.tmdb.org/t/p/original/';

export const fakeStoreAPI = 'https://fakestoreapi.com';
