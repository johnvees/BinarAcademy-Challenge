import Home from './Home';
import Login from './Login';
import Register from './Register';
import MovieDetail from './MovieDetail';

export {Home, Login, Register, MovieDetail};
