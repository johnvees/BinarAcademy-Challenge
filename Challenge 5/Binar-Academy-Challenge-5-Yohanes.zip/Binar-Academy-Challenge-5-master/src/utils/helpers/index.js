export const BASE_URL = 'http://code.aldipee.com/api/v1/books';

export const BASE_AUTH = 'http://code.aldipee.com/api/v1/auth';

export const TEMP_TOKEN =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2MjQ5NWU4Njk4YjVlOTdmYWUxNjYwMzMiLCJpYXQiOjE2NDkxNTE5NDMsImV4cCI6MTY0OTE1Mzc0MywidHlwZSI6ImFjY2VzcyJ9.xOjcrrWTo4FhIr-OO3bdQYDH1_Pu9qU4coNNOZNR6H8';
