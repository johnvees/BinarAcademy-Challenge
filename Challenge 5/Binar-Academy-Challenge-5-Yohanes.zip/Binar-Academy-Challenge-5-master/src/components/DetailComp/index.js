import DetailHeader from './detailHeader';
import DetailOverview from './detailOverview';
import DetailSoundPlayer from './detailSoundPlayer';

export {DetailHeader, DetailOverview, DetailSoundPlayer};
